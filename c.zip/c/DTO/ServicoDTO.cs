using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace c.DTO
{
    public class ServicoDTO
    {
        [Key]
        public int ServicoID { get; set; }

        [Required]
        public string NomeServico { get; set; }

        public string Descricao { get; set; }

        [Required]
        public int DuracaoMinutos { get; set; }

        [Required]
        public decimal Preco { get; set; }
    }
}