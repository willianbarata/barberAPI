using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace c.Models
{
    public class Agendamento
    {
        [Key]
        public int AgendamentoID { get; set; }

        [Required]
        public int ClienteID { get; set; }

        [Required]
        public DateTime DataHora { get; set; }

        public string Observacoes { get; set; }

        [Required]
        public int Status { get; set; }

        [ForeignKey("ClienteID")]
        public virtual Cliente Cliente { get; set; }

        public virtual ICollection<Servico> Servicos { get; set; }
    }
}