﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace c.Migrations
{
    public partial class primeira4 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
