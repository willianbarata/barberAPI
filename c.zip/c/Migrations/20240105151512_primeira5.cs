﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace c.Migrations
{
    public partial class primeira5 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AgendamentoServico");

            migrationBuilder.AddColumn<int>(
                name: "AgendamentoID",
                table: "Servicos",
                type: "INTEGER",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Servicos_AgendamentoID",
                table: "Servicos",
                column: "AgendamentoID");

            migrationBuilder.AddForeignKey(
                name: "FK_Servicos_Agendamentos_AgendamentoID",
                table: "Servicos",
                column: "AgendamentoID",
                principalTable: "Agendamentos",
                principalColumn: "AgendamentoID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Servicos_Agendamentos_AgendamentoID",
                table: "Servicos");

            migrationBuilder.DropIndex(
                name: "IX_Servicos_AgendamentoID",
                table: "Servicos");

            migrationBuilder.DropColumn(
                name: "AgendamentoID",
                table: "Servicos");

            migrationBuilder.CreateTable(
                name: "AgendamentoServico",
                columns: table => new
                {
                    AgendamentosAgendamentoID = table.Column<int>(type: "INTEGER", nullable: false),
                    ServicosServicoID = table.Column<int>(type: "INTEGER", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AgendamentoServico", x => new { x.AgendamentosAgendamentoID, x.ServicosServicoID });
                    table.ForeignKey(
                        name: "FK_AgendamentoServico_Agendamentos_AgendamentosAgendamentoID",
                        column: x => x.AgendamentosAgendamentoID,
                        principalTable: "Agendamentos",
                        principalColumn: "AgendamentoID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_AgendamentoServico_Servicos_ServicosServicoID",
                        column: x => x.ServicosServicoID,
                        principalTable: "Servicos",
                        principalColumn: "ServicoID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_AgendamentoServico_ServicosServicoID",
                table: "AgendamentoServico",
                column: "ServicosServicoID");
        }
    }
}
