using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using c.Data;
using c.DTO;
using c.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace c.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AgendamentoController : ControllerBase
    {
        private readonly ApplicationDbContext _dbContext;

        public AgendamentoController(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var agendamentos = await _dbContext.Agendamentos
                .Include(a => a.Cliente)
                .Include(a => a.Servicos)
                .ToListAsync();

            return Ok(agendamentos);
        }

        [HttpGet("{id:int}")]
        public async Task<ActionResult<Servico>> GetId(int id)
        {
            var agendamento = await _dbContext
                                .Agendamentos
                                .Include(a => a.Cliente)
                                .Include(a => a.Servicos)
                                .FirstOrDefaultAsync(x => x.AgendamentoID == id);


            if(agendamento == null)
            {
                return NotFound();
            }
            return Ok(agendamento);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] AgendamentoDTO agendamentoDTO)
        {
            if (ModelState.IsValid)
            {
                Agendamento agendamento = new Agendamento();
                agendamento.ClienteID = agendamentoDTO.ClienteID;
                agendamento.Observacoes = agendamentoDTO.Observacoes;
                agendamento.DataHora = agendamentoDTO.DataHora;
                agendamento.Servicos = new List<Servico>();
                agendamento.Cliente = _dbContext.Clientes.Find(agendamentoDTO.ClienteID);

                foreach (var item in agendamentoDTO.Servicos)
                {
                    var servico = _dbContext.Servicos.Find(item.ServicoID);
                    if(servico == null)
                    {
                        return BadRequest();
                    }
                    agendamento.Servicos.Add(servico);
                }

                _dbContext.Add(agendamento);
                await _dbContext.SaveChangesAsync();
                return Ok(agendamento);
            }

            return BadRequest();
        }
        
        // PUT: Agendamento/Edit/5
        [HttpPut("{id:int}")]
        public async Task<IActionResult> Edit(int id, [FromBody] AgendamentoDTO agendamentoDTO)
        {
            if (id != agendamentoDTO.AgendamentoID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                var agendamento = _dbContext.Agendamentos
                            .Include(a => a.Cliente)
                            .Include(a => a.Servicos)
                            .FirstOrDefault(x => x.AgendamentoID == agendamentoDTO.AgendamentoID);


                if(agendamento == null)
                {
                    return NotFound();
                }

                agendamento.DataHora = agendamentoDTO.DataHora;
                agendamento.Observacoes = agendamentoDTO.Observacoes;
                agendamento.Status = agendamentoDTO.Status;
                
                agendamento.Cliente = null;
                agendamento.ClienteID = agendamentoDTO.ClienteID;
                var cli = _dbContext.Clientes.Find(agendamentoDTO.ClienteID);
                agendamento.Cliente = cli;

                agendamento.Servicos.Clear();

                foreach (var item in agendamentoDTO.Servicos)
                {
                    var servico = _dbContext.Servicos.Find(item.ServicoID);
                    if(servico == null)
                    {
                        return BadRequest();
                    }
                    agendamento.Servicos.Add(servico);
                }

                try
                {
                    _dbContext.Update(agendamento);
                    await _dbContext.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException e)
                {
                    if (!AgendamentoExists(agendamento.AgendamentoID))
                    {
                        return NotFound(e.Message);
                    }
                    else
                    {
                        throw;
                    }
                }
                return Ok(agendamento);
            }

            return BadRequest();
        }

        // Delete: Agendamento/Delete/5
        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            var agendamento = await _dbContext.Agendamentos
                            .Include(a => a.Cliente)
                            .Include(a => a.Servicos)
                            .FirstOrDefaultAsync(x => x.AgendamentoID == id);

            _dbContext.Agendamentos.Remove(agendamento);
            await _dbContext.SaveChangesAsync();
            return Ok(agendamento);
        }

        private bool AgendamentoExists(int id)
        {
            return _dbContext.Agendamentos.Any(e => e.AgendamentoID == id);
        }
    }
}